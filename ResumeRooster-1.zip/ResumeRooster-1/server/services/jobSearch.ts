import axios from 'axios';
import { Job } from '@shared/schema';

interface JobSearchParams {
  query: string;
  location?: string;
  limit?: number;
  timeFilter?: string;
}

// Indeed Job Search API integration
export async function searchIndeedJobs(params: JobSearchParams): Promise<Job[]> {
  try {
    // Note: In production, you would use Indeed's official API
    // For now, we'll simulate the structure but return empty array since we don't have mock data
    const jobs: Job[] = [];
    
    // This would be the actual API call structure:
    // const response = await axios.get('https://api.indeed.com/ads/apisearch', {
    //   params: {
    //     publisher: process.env.INDEED_API_KEY,
    //     q: params.query,
    //     l: params.location,
    //     limit: params.limit || 25,
    //     format: 'json',
    //     v: '2'
    //   }
    // });
    
    return jobs;
  } catch (error) {
    console.error('Indeed API error:', error);
    return [];
  }
}

// LinkedIn Jobs API integration
export async function searchLinkedInJobs(params: JobSearchParams): Promise<Job[]> {
  try {
    // Note: LinkedIn requires OAuth and has specific API access requirements
    // This would be implemented with proper authentication
    const jobs: Job[] = [];
    
    return jobs;
  } catch (error) {
    console.error('LinkedIn API error:', error);
    return [];
  }
}

// Generic job aggregator service
export async function searchAllJobBoards(params: JobSearchParams): Promise<Job[]> {
  try {
    const [indeedJobs, linkedinJobs] = await Promise.allSettled([
      searchIndeedJobs(params),
      searchLinkedInJobs(params)
    ]);

    const allJobs: Job[] = [];

    if (indeedJobs.status === 'fulfilled') {
      allJobs.push(...indeedJobs.value);
    }

    if (linkedinJobs.status === 'fulfilled') {
      allJobs.push(...linkedinJobs.value);
    }

    // Remove duplicates based on title and company
    const uniqueJobs = allJobs.filter((job, index, self) => 
      index === self.findIndex(j => j.title === job.title && j.company === job.company)
    );

    return uniqueJobs;
  } catch (error) {
    console.error('Job search aggregation error:', error);
    return [];
  }
}

export function generateJobMatchScore(resumeSkills: string[], jobSkills: string[]): number {
  if (!resumeSkills.length || !jobSkills.length) return 0;
  
  const matchingSkills = resumeSkills.filter(skill => 
    jobSkills.some(jobSkill => 
      jobSkill.toLowerCase().includes(skill.toLowerCase()) ||
      skill.toLowerCase().includes(jobSkill.toLowerCase())
    )
  );
  
  return Math.round((matchingSkills.length / jobSkills.length) * 100);
}

export function filterJobsByTime(jobs: Job[], timeFilter: string): Job[] {
  const now = new Date();
  
  return jobs.filter(job => {
    const postedDate = new Date(job.postedDate);
    const timeDiff = now.getTime() - postedDate.getTime();
    const daysDiff = timeDiff / (1000 * 3600 * 24);
    
    switch (timeFilter) {
      case 'today':
        return daysDiff < 1;
      case 'tomorrow':
        return daysDiff >= -1 && daysDiff < 0;
      case 'within_week':
        return daysDiff <= 7;
      case 'before_week':
        return daysDiff > 7;
      default:
        return true;
    }
  });
}
