// Note: In production, you would install and use pdf-parse
// npm install pdf-parse @types/pdf-parse

export async function parseResumeText(fileBuffer: Buffer, filename: string): Promise<string> {
  try {
    const fileExtension = filename.split('.').pop()?.toLowerCase();
    
    if (fileExtension === 'pdf') {
      // const pdf = await import('pdf-parse');
      // const data = await pdf.default(fileBuffer);
      // return data.text;
      
      // For now, return a placeholder until pdf-parse is properly installed
      throw new Error('PDF parsing requires pdf-parse package to be installed');
    } else if (fileExtension === 'txt') {
      return fileBuffer.toString('utf-8');
    } else {
      throw new Error('Unsupported file format. Please upload PDF or TXT files.');
    }
  } catch (error) {
    console.error('Resume parsing error:', error);
    throw new Error(`Failed to parse resume: ${error.message}`);
  }
}

export function validateResumeFile(file: { size: number; mimetype: string }): boolean {
  const maxSize = 5 * 1024 * 1024; // 5MB
  const allowedTypes = [
    'application/pdf',
    'text/plain',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ];

  if (file.size > maxSize) {
    throw new Error('File size exceeds 5MB limit');
  }

  if (!allowedTypes.includes(file.mimetype)) {
    throw new Error('Unsupported file type. Please upload PDF, DOC, DOCX, or TXT files.');
  }

  return true;
}

export function extractSkillsFromText(text: string): string[] {
  // Common technical skills to look for
  const skillsPatterns = [
    // Programming languages
    /\b(JavaScript|TypeScript|Python|Java|C\+\+|C#|PHP|Ruby|Go|Rust|Swift|Kotlin)\b/gi,
    // Frameworks and libraries
    /\b(React|Angular|Vue|Node\.js|Express|Django|Flask|Spring|Laravel|Rails)\b/gi,
    // Databases
    /\b(MySQL|PostgreSQL|MongoDB|Redis|SQLite|Oracle|SQL Server)\b/gi,
    // Cloud platforms
    /\b(AWS|Azure|Google Cloud|GCP|Docker|Kubernetes|Terraform)\b/gi,
    // Tools and technologies
    /\b(Git|GitHub|GitLab|Jenkins|JIRA|Slack|Figma|Adobe|Photoshop)\b/gi,
  ];

  const skills = new Set<string>();
  
  skillsPatterns.forEach(pattern => {
    const matches = text.match(pattern);
    if (matches) {
      matches.forEach(match => skills.add(match.trim()));
    }
  });

  return Array.from(skills);
}

export function extractExperienceFromText(text: string): Array<{title: string, company: string, duration: string}> {
  // This is a simplified extraction - in production, you'd use more sophisticated NLP
  const experienceSection = text.match(/experience|work history|employment/i);
  if (!experienceSection) return [];

  // Look for common job title patterns
  const jobTitlePatterns = [
    /\b(Senior|Junior|Lead|Principal|Staff)?\s*(Software Engineer|Developer|Programmer|Analyst|Manager|Director|Coordinator|Specialist)\b/gi,
  ];

  const experience: Array<{title: string, company: string, duration: string}> = [];
  
  // This is a placeholder implementation
  // In production, you'd use proper NLP libraries to extract structured data
  
  return experience;
}
