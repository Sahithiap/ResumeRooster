import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export async function answerJobQuestion(question: string, context?: string): Promise<string> {
  try {
    const systemPrompt = `You are an expert career advisor and job search assistant. You help people with:
    - Job search strategies and tips
    - Career advice and guidance
    - Industry insights and trends
    - Resume and interview preparation
    - Salary negotiations
    - Skills development recommendations
    
    Provide helpful, accurate, and actionable advice. Be professional yet friendly.`;

    const userPrompt = context 
      ? `Context: ${context}\n\nQuestion: ${question}`
      : question;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      max_tokens: 500,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't process your question. Please try asking something else.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to get AI response. Please check your API key and try again.");
  }
}

export async function analyzeResumeForJobMatch(resumeContent: string, jobDescription: string): Promise<{
  matchScore: number;
  strengths: string[];
  gaps: string[];
  recommendations: string[];
}> {
  try {
    const prompt = `Analyze this resume against the job description and provide a detailed match analysis.

Resume Content:
${resumeContent}

Job Description:
${jobDescription}

Provide a JSON response with:
- matchScore: percentage (0-100) of how well the resume matches the job
- strengths: array of candidate's relevant strengths for this role
- gaps: array of missing skills or requirements
- recommendations: array of specific improvement suggestions

Respond only with valid JSON.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      matchScore: Math.max(0, Math.min(100, result.matchScore || 0)),
      strengths: result.strengths || [],
      gaps: result.gaps || [],
      recommendations: result.recommendations || []
    };
  } catch (error) {
    console.error("Resume analysis error:", error);
    throw new Error("Failed to analyze resume match. Please try again.");
  }
}

export async function extractResumeData(resumeText: string): Promise<{
  name: string;
  email: string;
  phone: string;
  skills: string[];
  experience: Array<{title: string, company: string, duration: string}>;
  education: Array<{degree: string, school: string, year: string}>;
}> {
  try {
    const prompt = `Extract structured data from this resume text and return it as JSON:

${resumeText}

Extract and return JSON with these fields:
- name: candidate's full name
- email: email address
- phone: phone number
- skills: array of technical and professional skills
- experience: array of work experience objects with title, company, duration
- education: array of education objects with degree, school, year

Return only valid JSON.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      name: result.name || "",
      email: result.email || "",
      phone: result.phone || "",
      skills: result.skills || [],
      experience: result.experience || [],
      education: result.education || []
    };
  } catch (error) {
    console.error("Resume parsing error:", error);
    throw new Error("Failed to extract resume data. Please try again.");
  }
}
