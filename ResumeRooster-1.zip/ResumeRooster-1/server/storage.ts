import { type User, type InsertUser, type Resume, type InsertResume, type Job, type InsertJob, type SearchQuery, type InsertSearchQuery, type AiConversation, type InsertAiConversation } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Resume methods
  getResume(id: string): Promise<Resume | undefined>;
  getResumesByUserId(userId: string): Promise<Resume[]>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResumeContent(id: string, content: string, parsedData: any): Promise<Resume | undefined>;

  // Job methods
  getJob(id: string): Promise<Job | undefined>;
  searchJobs(query: string, location?: string, filters?: any): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  getJobsByTimeFilter(timeFilter: string): Promise<Job[]>;

  // Search query methods
  createSearchQuery(searchQuery: InsertSearchQuery): Promise<SearchQuery>;
  getSearchQueriesByUserId(userId: string): Promise<SearchQuery[]>;

  // AI conversation methods
  getAiConversation(id: string): Promise<AiConversation | undefined>;
  createAiConversation(conversation: InsertAiConversation): Promise<AiConversation>;
  updateAiConversation(id: string, messages: Array<{role: string, content: string, timestamp: string}>): Promise<AiConversation | undefined>;
  getAiConversationsByUserId(userId: string): Promise<AiConversation[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private resumes: Map<string, Resume>;
  private jobs: Map<string, Job>;
  private searchQueries: Map<string, SearchQuery>;
  private aiConversations: Map<string, AiConversation>;

  constructor() {
    this.users = new Map();
    this.resumes = new Map();
    this.jobs = new Map();
    this.searchQueries = new Map();
    this.aiConversations = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getResume(id: string): Promise<Resume | undefined> {
    return this.resumes.get(id);
  }

  async getResumesByUserId(userId: string): Promise<Resume[]> {
    return Array.from(this.resumes.values()).filter(resume => resume.userId === userId);
  }

  async createResume(insertResume: InsertResume): Promise<Resume> {
    const id = randomUUID();
    const resume: Resume = { 
      ...insertResume, 
      id, 
      uploadedAt: new Date()
    };
    this.resumes.set(id, resume);
    return resume;
  }

  async updateResumeContent(id: string, content: string, parsedData: any): Promise<Resume | undefined> {
    const resume = this.resumes.get(id);
    if (!resume) return undefined;
    
    const updatedResume = { ...resume, content, parsedData };
    this.resumes.set(id, updatedResume);
    return updatedResume;
  }

  async getJob(id: string): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async searchJobs(query: string, location?: string, filters?: any): Promise<Job[]> {
    const jobs = Array.from(this.jobs.values());
    return jobs.filter(job => {
      const matchesQuery = !query || 
        job.title.toLowerCase().includes(query.toLowerCase()) ||
        job.company.toLowerCase().includes(query.toLowerCase()) ||
        job.description.toLowerCase().includes(query.toLowerCase());
      
      const matchesLocation = !location || 
        job.location.toLowerCase().includes(location.toLowerCase());
      
      let matchesFilters = true;
      if (filters) {
        if (filters.experienceLevel && filters.experienceLevel.length > 0) {
          matchesFilters = matchesFilters && filters.experienceLevel.includes(job.experienceLevel);
        }
        if (filters.jobType && filters.jobType.length > 0) {
          matchesFilters = matchesFilters && filters.jobType.includes(job.jobType);
        }
        if (filters.isRemote !== undefined) {
          matchesFilters = matchesFilters && job.isRemote === filters.isRemote;
        }
        if (filters.salaryMin) {
          matchesFilters = matchesFilters && (job.salaryMin || 0) >= filters.salaryMin;
        }
        if (filters.salaryMax) {
          matchesFilters = matchesFilters && (job.salaryMax || Infinity) <= filters.salaryMax;
        }
      }
      
      return matchesQuery && matchesLocation && matchesFilters;
    });
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = randomUUID();
    const job: Job = { ...insertJob, id };
    this.jobs.set(id, job);
    return job;
  }

  async getJobsByTimeFilter(timeFilter: string): Promise<Job[]> {
    const now = new Date();
    const jobs = Array.from(this.jobs.values());
    
    return jobs.filter(job => {
      const postedDate = new Date(job.postedDate);
      const timeDiff = now.getTime() - postedDate.getTime();
      const daysDiff = timeDiff / (1000 * 3600 * 24);
      
      switch (timeFilter) {
        case 'today':
          return daysDiff < 1;
        case 'tomorrow':
          return daysDiff >= -1 && daysDiff < 0;
        case 'within_week':
          return daysDiff <= 7;
        case 'before_week':
          return daysDiff > 7;
        default:
          return true;
      }
    });
  }

  async createSearchQuery(insertSearchQuery: InsertSearchQuery): Promise<SearchQuery> {
    const id = randomUUID();
    const searchQuery: SearchQuery = { 
      ...insertSearchQuery, 
      id, 
      searchedAt: new Date()
    };
    this.searchQueries.set(id, searchQuery);
    return searchQuery;
  }

  async getSearchQueriesByUserId(userId: string): Promise<SearchQuery[]> {
    return Array.from(this.searchQueries.values()).filter(query => query.userId === userId);
  }

  async getAiConversation(id: string): Promise<AiConversation | undefined> {
    return this.aiConversations.get(id);
  }

  async createAiConversation(insertConversation: InsertAiConversation): Promise<AiConversation> {
    const id = randomUUID();
    const conversation: AiConversation = { 
      ...insertConversation, 
      id, 
      createdAt: new Date()
    };
    this.aiConversations.set(id, conversation);
    return conversation;
  }

  async updateAiConversation(id: string, messages: Array<{role: string, content: string, timestamp: string}>): Promise<AiConversation | undefined> {
    const conversation = this.aiConversations.get(id);
    if (!conversation) return undefined;
    
    const updatedConversation = { ...conversation, messages };
    this.aiConversations.set(id, updatedConversation);
    return updatedConversation;
  }

  async getAiConversationsByUserId(userId: string): Promise<AiConversation[]> {
    return Array.from(this.aiConversations.values()).filter(conversation => conversation.userId === userId);
  }
}

export const storage = new MemStorage();
