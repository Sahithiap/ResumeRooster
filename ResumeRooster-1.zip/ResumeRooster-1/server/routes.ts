import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertResumeSchema, insertSearchQuerySchema, jobSearchFilters } from "@shared/schema";
import { answerJobQuestion, analyzeResumeForJobMatch, extractResumeData } from "./services/openai";
import { searchAllJobBoards, generateJobMatchScore, filterJobsByTime } from "./services/jobSearch";
import { parseResumeText, validateResumeFile, extractSkillsFromText } from "./services/resumeParser";
import multer from 'multer';

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Search jobs
  app.get("/api/jobs/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const location = req.query.location as string;
      const timeFilter = req.query.timeFilter as string;
      const filters = req.query.filters ? JSON.parse(req.query.filters as string) : {};

      // Validate filters
      const validatedFilters = jobSearchFilters.parse(filters);

      // Search in stored jobs first
      let jobs = await storage.searchJobs(query, location, validatedFilters);

      // If no local results, search external job boards
      if (jobs.length === 0) {
        jobs = await searchAllJobBoards({ query, location, timeFilter });
        
        // Store new jobs in local storage
        for (const job of jobs) {
          await storage.createJob(job);
        }
      }

      // Apply time filtering
      if (timeFilter && timeFilter !== 'any') {
        jobs = filterJobsByTime(jobs, timeFilter);
      }

      // Save search query
      if (query) {
        await storage.createSearchQuery({
          userId: null, // For now, not requiring user auth
          query,
          location: location || null,
          filters: validatedFilters,
          resultCount: jobs.length
        });
      }

      res.json({
        jobs,
        total: jobs.length,
        query,
        location,
        filters: validatedFilters
      });
    } catch (error) {
      console.error("Job search error:", error);
      res.status(500).json({ 
        message: "Failed to search jobs", 
        error: error.message 
      });
    }
  });

  // Upload and parse resume
  app.post("/api/resumes/upload", upload.single('resume'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Validate file
      validateResumeFile({
        size: req.file.size,
        mimetype: req.file.mimetype
      });

      // Parse resume text
      const resumeText = await parseResumeText(req.file.buffer, req.file.originalname);

      // Extract structured data using AI
      const parsedData = await extractResumeData(resumeText);

      // Create resume record
      const resume = await storage.createResume({
        userId: null, // For now, not requiring user auth
        filename: req.file.originalname,
        content: resumeText,
        parsedData
      });

      res.json({
        resumeId: resume.id,
        parsedData,
        message: "Resume uploaded and analyzed successfully"
      });
    } catch (error) {
      console.error("Resume upload error:", error);
      res.status(500).json({ 
        message: "Failed to upload resume", 
        error: error.message 
      });
    }
  });

  // Get resume-based job recommendations
  app.get("/api/jobs/recommendations/:resumeId", async (req, res) => {
    try {
      const { resumeId } = req.params;
      const resume = await storage.getResume(resumeId);
      
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }

      // Get user's skills from parsed resume data
      const userSkills = resume.parsedData?.skills || [];
      
      // Search for jobs
      const allJobs = await storage.searchJobs("", undefined, {});
      
      // Calculate match scores for each job
      const jobsWithScores = allJobs.map(job => ({
        ...job,
        matchScore: generateJobMatchScore(userSkills, job.skills || [])
      }));

      // Sort by match score and return top matches
      const recommendations = jobsWithScores
        .sort((a, b) => b.matchScore - a.matchScore)
        .slice(0, 20);

      res.json({
        recommendations,
        userSkills,
        totalJobs: allJobs.length
      });
    } catch (error) {
      console.error("Job recommendation error:", error);
      res.status(500).json({ 
        message: "Failed to get job recommendations", 
        error: error.message 
      });
    }
  });

  // AI Chat endpoint
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const response = await answerJobQuestion(message, context);
      
      res.json({
        response,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ 
        message: "Failed to get AI response", 
        error: error.message 
      });
    }
  });

  // Analyze job match for specific resume and job
  app.post("/api/jobs/:jobId/analyze-match", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { resumeId } = req.body;

      const job = await storage.getJob(jobId);
      const resume = await storage.getResume(resumeId);

      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }

      const analysis = await analyzeResumeForJobMatch(resume.content, job.description);

      res.json({
        jobId,
        resumeId,
        analysis
      });
    } catch (error) {
      console.error("Job match analysis error:", error);
      res.status(500).json({ 
        message: "Failed to analyze job match", 
        error: error.message 
      });
    }
  });

  // Get job details
  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const job = await storage.getJob(id);

      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      res.json(job);
    } catch (error) {
      console.error("Get job error:", error);
      res.status(500).json({ 
        message: "Failed to get job details", 
        error: error.message 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
