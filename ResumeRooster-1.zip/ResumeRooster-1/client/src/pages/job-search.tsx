import { useState } from "react";
import Header from "@/components/header";
import SearchBar from "@/components/search-bar";
import FiltersSidebar from "@/components/filters-sidebar";
import JobCard from "@/components/job-card";
import AiChatWidget from "@/components/ai-chat-widget";
import ResumeUploadModal from "@/components/resume-upload-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Upload, Bot } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { JobSearchFilters } from "@shared/schema";

export default function JobSearchPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [location, setLocation] = useState("");
  const [filters, setFilters] = useState<JobSearchFilters>({});
  const [showResumeModal, setShowResumeModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [resumeId, setResumeId] = useState<string | null>(null);

  const { data: jobResults, isLoading } = useQuery({
    queryKey: ["/api/jobs/search", { q: searchQuery, location, filters }],
    enabled: false, // Only search when user submits
  });

  const { data: recommendations } = useQuery({
    queryKey: ["/api/jobs/recommendations", resumeId],
    enabled: !!resumeId,
  });

  const handleSearch = () => {
    // Trigger search by updating query key
    setCurrentPage(1);
  };

  const handleResumeUpload = (uploadedResumeId: string) => {
    setResumeId(uploadedResumeId);
    setShowResumeModal(false);
  };

  const jobs = jobResults?.jobs || [];
  const totalJobs = jobResults?.total || 0;
  const showRecommendations = recommendations && recommendations.recommendations.length > 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Resume Upload Banner */}
        <div className="bg-gradient-to-r from-primary to-primary-dark rounded-xl p-6 mb-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Get Personalized Job Matches</h2>
              <p className="text-blue-100">Upload your resume for AI-powered job recommendations</p>
            </div>
            <Button 
              onClick={() => setShowResumeModal(true)}
              className="bg-white text-primary hover:bg-gray-50"
              data-testid="button-upload-resume"
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload Resume
            </Button>
          </div>
        </div>

        {/* Search Section */}
        <SearchBar
          query={searchQuery}
          location={location}
          onQueryChange={setSearchQuery}
          onLocationChange={setLocation}
          onSearch={handleSearch}
          filters={filters}
          onFiltersChange={setFilters}
        />

        {/* Results Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mt-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <FiltersSidebar filters={filters} onFiltersChange={setFilters} />
          </div>

          {/* Job Results */}
          <div className="lg:col-span-3">
            {/* Results Header */}
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900" data-testid="text-results-count">
                  {totalJobs} jobs found
                </h2>
                <p className="text-gray-600 text-sm">
                  {showRecommendations ? "Sorted by: Best match for your profile" : "Sorted by: Most recent"}
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm" data-testid="select-sort">
                  <option value="best_match">Best Match</option>
                  <option value="most_recent">Most Recent</option>
                  <option value="salary_high">Salary: High to Low</option>
                  <option value="distance">Distance</option>
                </select>
              </div>
            </div>

            {/* AI Recommendations Banner */}
            {showRecommendations && (
              <div className="bg-gradient-to-r from-ai-purple to-purple-600 rounded-xl p-4 mb-6 text-white">
                <div className="flex items-center">
                  <Bot className="h-6 w-6 mr-3" />
                  <div>
                    <h3 className="font-semibold">AI-Powered Recommendations</h3>
                    <p className="text-purple-100 text-sm">
                      Based on your resume, these jobs are highly matched for your skills
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Loading State */}
            {isLoading && (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Card key={i} className="p-6">
                    <div className="animate-pulse">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {/* Job Cards */}
            {!isLoading && jobs.length === 0 && (
              <Card className="p-8 text-center">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No jobs found</h3>
                <p className="text-gray-600">
                  Try adjusting your search criteria or upload your resume for personalized recommendations.
                </p>
              </Card>
            )}

            <div className="space-y-4">
              {(showRecommendations ? recommendations.recommendations : jobs).map((job) => (
                <JobCard key={job.id} job={job} resumeId={resumeId} />
              ))}
            </div>

            {/* Pagination */}
            {totalJobs > 25 && (
              <div className="mt-8">
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        href="#" 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        data-testid="button-pagination-previous"
                      />
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#" isActive={currentPage === 1} data-testid="link-page-1">
                        1
                      </PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#" data-testid="link-page-2">2</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#" data-testid="link-page-3">3</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationNext 
                        href="#" 
                        onClick={() => setCurrentPage(p => p + 1)}
                        data-testid="button-pagination-next"
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* AI Chat Widget */}
      <AiChatWidget />

      {/* Resume Upload Modal */}
      <ResumeUploadModal
        open={showResumeModal}
        onOpenChange={setShowResumeModal}
        onUploadSuccess={handleResumeUpload}
      />
    </div>
  );
}
